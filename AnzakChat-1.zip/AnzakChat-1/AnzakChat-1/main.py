from flask import Flask, render_template, request, redirect, session, jsonify
import firebase_admin
from firebase_admin import credentials, db
import uuid

app = Flask(__name__)
app.secret_key = 'supersecretkey'

cred = credentials.Certificate("anzakchat-4d922-firebase-adminsdk-fbsvc-7105390052.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://anzakchat-4d922-default-rtdb.europe-west1.firebasedatabase.app/'
})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        if not username or not password:
            return render_template('signup.html', error="Ad soyad ve şifre zorunludur!")

        users_ref = db.reference('users')
        users = users_ref.get() or {}

        # Aynı kullanıcı adı varsa kayıt engelle
        for user in users.values():
            if user['username'].lower() == username.lower():
                return render_template('signup.html', error="Bu ad soyad ile zaten kayıt olunmuş!")

        # Yeni kullanıcı ekle
        new_id = str(uuid.uuid4())
        users_ref.child(new_id).set({
            'username': username,
            'password': password
        })
        return redirect('/')
    else:
        return render_template('signup.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username'].strip()
    password = request.form['password'].strip()
    users = db.reference('users').get() or {}

    for user_id, user in users.items():
        if user['username'].lower() == username.lower():
            if user['password'] == password:
                session['user'] = user['username']
                session['uid'] = user_id
                return redirect('/menu')
            else:
                return render_template('index.html', error="Şifre yanlış!")
    return render_template('index.html', error="Kullanıcı adı bulunamadı!")

@app.route('/menu')
def menu():
    if 'user' not in session:
        return redirect('/')
    rooms = db.reference('rooms').get() or {}
    return render_template('menu.html', username=session['user'], rooms=rooms)

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/create_room', methods=['POST'])
def create_room():
    if 'user' not in session:
        return redirect('/')
    room_name = request.form['roomname'].strip()
    room_pass = request.form['roompass'].strip()
    if not room_name or not room_pass:
        return redirect('/menu')
    room_id = str(uuid.uuid4())
    db.reference('rooms').child(room_id).set({
        'name': room_name,
        'password': room_pass,
        'owner': session['user']
    })
    return redirect('/menu')

@app.route('/join_room', methods=['POST'])
def join_room():
    room_id = request.form['room_id']
    room_pass = request.form['roompass'].strip()
    room = db.reference('rooms').child(room_id).get()
    if room and room['password'] == room_pass:
        session['room_id'] = room_id
        session['room_name'] = room['name']
        return redirect('/chat')
    return render_template('menu.html', username=session['user'], rooms=db.reference('rooms').get() or {}, error="Oda şifresi yanlış veya oda bulunamadı!")

@app.route('/chat')
def chat():
    if 'user' not in session or 'room_id' not in session:
        return redirect('/')
    return render_template('chat.html', username=session['user'], room=session['room_name'])

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'user' not in session or 'room_id' not in session:
        return '', 403
    message = request.form['message'].strip()
    if not message:
        return '', 204
    db.reference('messages').child(session['room_id']).push({
        'user': session['user'],
        'text': message
    })
    return '', 204

@app.route('/get_messages')
def get_messages():
    if 'room_id' not in session:
        return jsonify([])
    messages = db.reference('messages').child(session['room_id']).get() or {}
    return jsonify(list(messages.values()))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
